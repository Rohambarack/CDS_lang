sudo apt-get update
sudo apt-get install -y python3-opencv
pip install opencv-python
pip install matplotlib
pip install pandas
pip install numpy
pip install scikit-learn
pip install tensorflow
Assignment 1 for Visual Analytics in Cultural Data Science
Folders:
in: input, flower images
out: where output .csv files are saved
code: python notebook for extracting color histogram information from images,
and comparing all histogram distances to a certain set image file.
Distance is calculated with chi square
the 5 closest images to target image  
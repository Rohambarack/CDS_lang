import os
os.system("pip install gensim pandas")
import re
import argparse
from collections import Counter
import pandas as pd
import gensim

def input_parser():
    parser =  argparse.ArgumentParser(description='Spotify assignment inputs')
    parser.add_argument('--artist',
                        "-a",
                        required = True,
                        help='Name of artist')
    parser.add_argument('--query_word',
                        "-qw",
                        required = True,
                        help='Word, which should be found in the discography')
    parser.add_argument('--data',
                        "-d",
                        default = "data_spoty.csv",
                        help='Dataset in the "in" folder. Default is the spotify dataset, data_spoty.csv')
    parser.add_argument('--model',
                        "-m",
                        default = "../in/model/english_word2vec.bin",
                        help='Path to word embedding model')
    parser.add_argument('--n_embeds',
                        "-n_e",
                        default = 10,
                        help='extends the query to these amount of closest terms')
    

    args = parser.parse_args()
    return args

def clean_text(text):
    clean_text = re.sub(r"""
                    [,.;@#?!&$\n]+  # Accept one or more copies of punctuation
                    \ *           # plus zero or more copies of a space,
                    """,
                    " ",          # and replace it with a single space
                    text.lower(), flags=re.VERBOSE)
    return clean_text


def non_zero_counter(list_of_values):
    non_zero_counter = 0
    for count in list_of_values:
        if type(count) != str: #the first is the title so that is a str

            if count > 0:
                    non_zero_counter += 1
        else:
            pass
    else:
        pass

    return non_zero_counter

def make_output_tables(query_result, max_row):
    #make tables
    #extended table
    ex_data = pd.DataFrame(query_result["song"])
    ex_data
    #small info table
    small_df = pd.DataFrame(columns=["Artist","Term","Percentage","All_Percentage","N_Songs"])
    #add terms
    small_df.Term = ex_data.columns[1:len(ex_data.columns)]
    #add artist
    small_df.Artist = ex_data.columns[0] 
    #add n_songs
    small_df.N_Songs = max_row
    #add all_percentage
    small_df.All_Percentage = round(len(ex_data)/max_row*100,2)
    #add percentages for each query term
    #look through all colums of the terms in the big set, find non zeros, make it a list
    ex_data.fillna(0)
    percentages = []
    for col in ex_data.columns[1:len(ex_data.columns)]:
        n_z_count = non_zero_counter(ex_data[col])
        percentages.append(round(n_z_count/max_row*100,2))

    small_df.Percentage = percentages

    return ex_data, small_df

class Extended_Query:

    def __init__(self, data, model, artist, q_word, n_embeds):
        self.data = data
        self.model = model
        self.n_embeds = n_embeds
        self.artist = artist
        self.q_word = q_word
    
    def create_query(self):
        """ Method for creating a query from model and data,
        based on artist and query extension size
        - data: csv file with columns: 'artist', title as 'song', lyrics as 'text
        - model: word embedding model
        - artist: name of artist
        - q_word: lowercase str without punctuations.
        - n_embed: additional query extensions based on proximity in the embedding model"""
        #subset
        singer = self.artist
        sub_data = self.data.loc[self.data['artist'] == singer]
        #embed
        query_word = self.q_word
        n_similar = self.n_embeds
        query_array = self.model.most_similar(query_word,topn=n_similar)
        query_array.append((query_word, 1))

        # find in subset (subset rows by indexing row number to sub_data.loc)
        max_row = len(sub_data.index)
        occurence_count_full = {"song":[]}
        for row_index in range(0,max_row):
            row = sub_data.loc[row_index]
            song_title = row["song"]
            song_lyric = row["text"]
            artist = row["artist"]
            #clean lyrics to be compatible with the word embedding labels
            clean_lyric = clean_text(song_lyric)
            #for each word in list
            occurence_count = {}
            for word_value_pair in query_array:
                target_word = word_value_pair[0]
                #count list elements in lyric
                n_occurences = clean_lyric.split().count(target_word)
                temporary_dict = {artist:song_title,target_word:n_occurences}
                #check counts in the dictionary. if none found, it isn't saved
                n_z_counter = non_zero_counter(temporary_dict.values())

                if n_z_counter > 0:
                    occurence_count.update(temporary_dict)
                else:
                    pass

            #append dict if not empty
            if len(occurence_count) > 0:     
                occurence_count_full["song"].append(occurence_count)
            else:
                pass
        return occurence_count_full, max_row

def main():
    args = input_parser()
    #model
    #model_name = args.model
    #model_path = os.path.join("..","in","model",model_name)
    model_path = args.model
    model = gensim.models.KeyedVectors.load(model_path)
    #data
    data_name = args.data
    data_path = os.path.join("..","in","data",data_name)
    data = pd.read_csv(data_path)

    query_class = Extended_Query(model = model,
                                 data = data,
                                 artist = args.artist,
                                 q_word = args.query_word,
                                 n_embeds = args.n_embeds)
    
    query, n_songs = query_class.create_query()
    
    extendend_table, small_table  = make_output_tables(query, n_songs)

    #save output
    filename_1 = "extended_query.csv"
    output_path = os.path.join("..","out",filename_1)
    extendend_table.to_csv(output_path, index=True)
    filename_2 = "small_table.csv"
    output_path = os.path.join("..","out",filename_2)
    small_table.to_csv(output_path, index=False)

if __name__ == "__main__":
    main()